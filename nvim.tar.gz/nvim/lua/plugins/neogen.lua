return {
  "danymat/neogen",
  config = true,
}
